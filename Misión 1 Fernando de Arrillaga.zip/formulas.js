
function areaTriangulo(b,a){
    alert(base*altura);


};
function permietroTrianguloEquilatero(l){
    alert (lado1*3);
};
function perimetroTrianguloIsosceles(l1, l2){
    alert (lado1*2+lado2);
};
function permietroTrianguloEscaleno(l1,l2,l3){
 
    alert (lado1+lado2+lado3);
};
function areaCuadrado(l){
 
    alert (lado1*lado1);
};
function perimetroCuadrado(l){
    
    alert (lado1*4);
};
function areaRectangulo(l1,l2){
    
    alert (lado1*lado2);
};
function areaCirculo(r){
    
    alert(Math.PI*Math.pow(radio,2));
};
function longitudCircunferencia(r){
    var longitud=2*Math.PI*r;
    alert(2*Math.PI*radio);
};