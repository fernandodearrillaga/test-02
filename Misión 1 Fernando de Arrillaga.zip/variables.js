var base=3;
var b=base;
var altura=5;
var a=altura;
var lado1=2;
var l=lado1;
var lado2=5;
var lado3=4;
var radio=6;
// inicializo más variables
//var area=b*a;