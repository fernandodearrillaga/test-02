function final(){
    if (aciertos==4){
        alert("Has ganado");
    }
    else{
        alert("Has perdido");
    }
}